//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

import com.google.common.base.Stopwatch;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Main implements ActionListener {

    private static JTextField dateText;
    private static JFrame frame;

    public static void main(String[] args) {

        frame = new JFrame();

        JLabel dateQ = new JLabel("Enter Date of Matches ->");
        dateQ.setBounds(10, 50, 80, 100);

        Date date = Calendar.getInstance().getTime();
        DateFormat dateOnly = new SimpleDateFormat("dd/MM/yyyy");
        String todaysDate = dateOnly.format(date);
        dateText = new JTextField(todaysDate);
        dateText.select(0, dateText.getText().length());
        dateText.setBounds(100, 50, 165, 25);


        JButton button = new JButton("Check Matches");
        button.addActionListener(new Main());


        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(120, 120, 40, 120));
        panel.setLayout(new GridLayout(0, 2));
        panel.add(dateQ);
        panel.add(dateText);
        panel.add(button);


        frame.add(panel, BorderLayout.CENTER);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Check LJ's Live on Sat for Matches");
        frame.pack();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }


    public void actionPerformed(ActionEvent e) {
        String date = dateText.getText();

        Stopwatch stopwatch = Stopwatch.createStarted();


        frame.dispose();
        //Set WebDriver Location
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win32\\chromedriver.exe");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("--headless=new");
        options.addArguments("--disable-gpu");
        options.addArguments("--no-sandbox");
        options.addArguments("--allow-insecure-localhost");
        options.addArguments("--proxy-server='direct://'");
        options.addArguments("--proxy-bypass-list=*");

        ChromeDriver driver = new ChromeDriver(options);

        var dateStringNumbers = date.replace("/", "");

        //Format Dates
        String dayDate = dateStringNumbers.substring(0, 2);
        String monthDate = dateStringNumbers.substring(2, 4);
        int yearDate = Integer.parseInt(dateStringNumbers.substring(4, 8));


        //Access the Website
        driver.get("https://liveonsat.com/2day.php?start_dd=" + dayDate + "&start_mm=" + monthDate + "&start_yyyy=" + yearDate + "&end_dd=" + dayDate + "&end_mm=" + monthDate + "&end_yyyy=" + yearDate);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


        //Remove Consent if applicable
        if (driver.findElement(By.xpath("//div[contains(@class, 'fc-dialog fc-choice-dialog')]")).isDisplayed()) {
            driver.findElement(By.xpath("//button[contains(@aria-label, 'Consent')] //p[contains(text(), 'Consent')]")).click();
        }


        //Find FTA matches
        int numberOfFTAMatches = driver.findElements(By.xpath("//div //a [contains(@class, 'chan_live_free')]")).size();


        //Create filewriter
        try {
            PrintWriter writer = new PrintWriter("FTAFootballToday.txt");
            writer.write("###**FTA Football Shown On: **" + "_" + date + "_");
            writer.write("\n");
            writer.write("Updated Channels: http://bit.ly/3Qj2eLD (M3U Format)");
            writer.write("\n");
            writer.write("\n");


            ArrayList<String> matchEventList = new ArrayList<>();
            matchEventList.add("Test");
            String matchName;
            String matchTime;
            String matchChannel;
//            driver.manage().window().minimize();

            for (int i = 1; i <= numberOfFTAMatches; i++) {

                //get the match event
                matchName = String.valueOf(driver.findElement(By.xpath("(//div //a [contains(@class, 'chan_live_free')])" + "[" + i + "] " + "/../../../../../../../..//div[@class ='fix']")).getText());
                matchTime = String.valueOf(driver.findElement(By.xpath("(//div //a [contains(@class, 'chan_live_free')])" + "[" + i + "] " + "/../../../../../../../..//div[@class ='fLeft_time_live']")).getText());
                String matchTimeSubString = matchTime.substring(4);
                matchChannel = String.valueOf(driver.findElement(By.xpath("(//div //a [contains(@class, 'chan_live_free')])" + " [" + i + "]")).getText());


                if (!matchEventList.contains(matchName)) {
                    matchEventList.add(matchName);

                    if (i != 1) {
                        writer.write("\n");
                        writer.write("\n");
                    }

                    ////

                    if (driver.findElement(By.xpath("(//div //a [contains(@class, 'chan_live_free')])" + "[" + i + "] " + "/../../../../../../../..//div[@class ='fix'] //div //div [2]")).getCssValue("background-color").toString().equals("rgba(255, 192, 203, 1)")) {
                        writer.write(i + ") **" + matchName + "**" + " (" + matchTimeSubString + ") **[Women]**");
                        writer.write("\n");
                        writer.write(matchChannel);
                    } else {
                        writer.write(i + ") **" + matchName + "**" + " (" + matchTimeSubString + ")");
                        writer.write("\n");
                        writer.write(matchChannel);
                    }

                } else {
                    writer.write("\n");
                    writer.write(matchChannel);
                }
            }


            writer.write("\n");
            writer.write("\n");
            writer.write("Additional Info:");
            writer.write("\n");
            writer.write("There are " + (matchEventList.size() - 1) + " matches available Free To Air on " + date + " according to LJ's Live on Sat.");
            writer.flush();
            writer.close();

            String everything = "";


            try (BufferedReader br = new BufferedReader(new FileReader("FTAFootballToday.txt"))) {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                //Everything and SB print out everything (stored in variable)

                while (line != null) {
                    sb.append(line);
                    sb.append(System.lineSeparator());
                    line = br.readLine();
                }
                everything = sb.toString();

            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }

            //Post To Pastebin
            driver.get("https://rentry.co/i4wciux3/edit");
            String editCode = "tpExxVMn";


            Thread.sleep(500);
            driver.findElement(By.xpath("//input [@name = 'edit_code']")).click();
            driver.findElement(By.xpath("//input [@name = 'edit_code']")).sendKeys(editCode);
            Thread.sleep(500);
            driver.findElement(By.xpath("//div [@class = 'CodeMirror-lines']")).click();
            Thread.sleep(500);

            WebElement l = driver.findElement(By.xpath("//span [@role='presentation']"));

            l.sendKeys(Keys.chord(Keys.CONTROL, "a"));
            Thread.sleep(200);
            l.sendKeys(Keys.chord(Keys.DELETE));


            Thread.sleep(500);
            String characterFilter = "[^\\p{L}\\p{M}\\p{N}\\p{P}\\p{Z}\\p{Cf}\\p{Cs}\\s]";
            String emotionless = everything.replaceAll(characterFilter, "");
            System.out.println(emotionless);
            driver.findElement(By.xpath("//span [@role='presentation']")).sendKeys(emotionless + "Runtime: " + stopwatch.toString().replace("s", "").trim() + " seconds");
            driver.findElement(By.xpath("//span [@role='presentation']")).sendKeys("\n" + "Last Updated: " + LocalDateTime.now().getDayOfMonth() + "/" + LocalDateTime.now().getMonthValue() + "/" + LocalDateTime.now().getYear() + " @ " + LocalDateTime.now().toLocalTime().format(DateTimeFormatter.ISO_LOCAL_TIME).substring(0, 5));


            Thread.sleep(500);
            driver.findElement(By.xpath("//button [@id = 'submitButton']")).click();

            stopwatch.stop();
            System.out.println("This script took " + stopwatch + " to run");

            Thread.sleep(1000);
            driver.close();
            System.exit(0);


        } catch (FileNotFoundException | InterruptedException ex) {
            throw new RuntimeException(ex);
        }


        //Pastebin
        //login: nolakib400@fryshare.com
        //FTAFootballUser
        //FTAFootballUser101
        //https://pastebin.com/fkbF2dCL
    }
}
